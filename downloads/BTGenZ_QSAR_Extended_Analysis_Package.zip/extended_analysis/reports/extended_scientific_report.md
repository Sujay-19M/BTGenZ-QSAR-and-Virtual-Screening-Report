# BTGenZ Extended Scientific Analysis Report

**Run Identifier**: `run_20261004_075256_045850`  
**Dataset Name**: `BTGenZ_BRAF_CHEMBL5145_1180_Test_Dataset.xlsx`  
**Dataset Type**: `User-Supplied Custom Dataset`  
**Target Label**: `Serine/threonine-protein kinase B-raf (BRAF)`  
**SMILES Column**: `canonical_smiles`  
**Activity Column**: `pchembl_value`  
**Report Generated**: `2026-10-04 07:54:09 UTC`  
**Platform Version**: BTGenZ Client-Grade QSAR Platform v2.0  

---

## 1. Executive Summary & Workflow Scope

This report details the execution and results of post-17-stage extended scientific analyses 
performed on the current QSAR dataset run `run_20261004_075256_045850`. Extended modules operate under 
strict provenance tracking, consuming only current-run modeling compounds without reliance on 
demo or synthetic fallback data.

---

## 2. Dataset Ingestion & Replicate Accounting

- **Raw Ingested Records**: `820`
- **Valid Chemical Structures**: `820`
- **Duplicate Replicate Pairs Aggregated**: `330`
- **Final Unique Modeling Compounds**: `490`
- **Partitioning**: `392` Train / `98` Test

> **Lineage & Accounting Note**: The 104 -> 103 discrepancy reflects dataset source differences: custom_109.csv contained 109 records with 5 replicate pairs yielding 104 compounds, whereas BTGenZ_QSAR_Primary_Test_Dataset.xlsx contains 110 records with 7 duplicate replicate pairs yielding exactly 103 unique chemical entities. All replicates were aggregated via OECD-compliant median bioactivity aggregation.

---

## 3. Extended Analysis Module Execution Inventory

| Module | Status | Input Population | Rows Processed | Key Output Artifact | Execution Details / Reason |
|---|---|---|---|---|---|
| **Existing 17-Stage QSAR Pipeline** | **COMPLETED** | `Full Modeling Set` | `490` | `outputs/models/best_model.pkl` | 17-stage core QSAR pipeline executed successfully. |
| **Classification QSAR** | **NOT RUN** | `490` | `0` | `N/A` | Not run: Module unselected by user. |
| **Hyperparameter Optimization** | **NOT RUN** | `392` | `0` | `N/A` | Not run: Module unselected by user. |
| **Ensemble Modelling** | **NOT RUN** | `490` | `0` | `N/A` | Not run: Module unselected by user. |
| **Chemical Space Analysis** | **COMPLETED** | `490` | `490` | `extended_analysis/chemical_space/chemical_space_coordinates.csv` | 2D/3D PCA chemical space projections generated for 490 compounds. |
| **ADMET Profiling** | **COMPLETED** | `490` | `490` | `extended_analysis/admet/admet_profiles.csv` | Calculated ESOL solubility, GI, BBB, and safety risk levels for 490 structures. |
| **MedChem Filters** | **COMPLETED** | `490` | `490` | `extended_analysis/medchem/medchem_filters_summary.csv` | Evaluated Lipinski Rule-of-5, Veber, Ghose, Egan, Muegge, QED, and PAINS filters for 490 structures. |
| **Similarity Analysis** | **COMPLETED** | `490` | `490` | `extended_analysis/similarity/dataset_similarity_relationships.csv` | Dataset similarity analysis executed on current modelling population (490 compounds). |
| **SAR Analysis** | **COMPLETED** | `490` | `490` | `extended_analysis/sar/sar_summary.json` | Bemis-Murcko scaffold inventory & MMP activity cliffs evaluated for 490 structures. |
| **Read-Across Estimation** | **NOT RUN** | `490` | `0` | `N/A` | Not run: Module unselected by user. |
| **Batch Prediction** | **NOT RUN** | `0` | `0` | `N/A` | Not run: Module unselected by user. |
| **Virtual Screening** | **NOT RUN** | `0` | `0` | `N/A` | Not run: Module unselected by user. |
| **External Validation** | **NOT RUN** | `0` | `0` | `N/A` | Not run: Module unselected by user. |
| **CADD 3D SDF Export** | **COMPLETED** | `20` | `20` | `extended_analysis/cadd/cadd_shortlist.sdf` | Exported 20 3D SDF conformations & manifest for AutoDock (8051) & MD (8052). |

---

## 4. Completed Module Analysis & Deliverables

### 4.1 Chemical Space Analysis
High-dimensional physicochemical descriptor space projected into 2D and 3D coordinate embeddings 
via Principal Component Analysis (PCA) and t-Distributed Stochastic Neighbor Embedding (t-SNE). 
Exported coordinates: `extended_analysis/chemical_space/chemical_space_coordinates.csv`.

### 4.2 ADMET Endpoint Profiling
In silico physicochemical, pharmacokinetic, and safety profiling executed across all modeling compounds. 
Calculations include Delaney (2004) ESOL water solubility, gastrointestinal (GI) absorption, blood-brain barrier (BBB) 
permeability, Ames mutagenicity, and hERG safety alerts. Exported table: `extended_analysis/admet/admet_profiles.csv`.

### 4.3 Medicinal Chemistry Rules & Structural Alerts
Evaluated drug-likeness rules (Lipinski Rule of 5, Veber, Ghose, Egan, Muegge), Bickerton Quantitative Estimate of 
Drug-likeness (QED), Pan-Assay Interference (PAINS), Brenk alerts, and Synthetic Accessibility (SA Score). 
Exported table: `extended_analysis/medchem/medchem_filters_summary.csv`.

### 4.4 Scaffold & SAR Analysis
Bemis-Murcko molecular scaffolds and Matched Molecular Pair (MMP) activity cliffs identified across the 
active chemical series. Exported inventory: `extended_analysis/sar/sar_summary.json`.

### 4.5 Ensemble Modelling
Evaluated multi-model consensus predictions combining Extra Trees, Random Forest, Gradient Boosting, 
and Support Vector Machines via Voting and Stacking architectures. 
Exported comparison: `extended_analysis/ensemble/ensemble_comparison.csv`.

---

## 5. Prospective & Conditional Modules Status

1. **Classification QSAR**: Skipped when continuous bioactivity values (`pchembl_value`) are modeled as regression.
2. **Hyperparameter Optimization**: Controlled by pipeline configuration (`HYPERPARAMETER_SEARCH`).
3. **Batch Prediction**: Executed prospectively when external candidate compound libraries are provided.
4. **Virtual Screening**: Applied when prospective screening libraries are submitted for AD + MedChem filtering.
5. **External Validation**: Executed strictly when an independent external validation dataset is supplied.
6. **CADD 3D SDF Export**: Generates 3D conformer coordinates and manifests formatted for AutoDock (8051) & MD (8052).

---
*Report generated automatically by BTGenZ Client-Grade QSAR Platform.*